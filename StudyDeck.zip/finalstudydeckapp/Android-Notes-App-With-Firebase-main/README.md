# Android-Notes-App-With-Firebase

<img width="250" alt="Screen Shot 2023-01-30 at 19 12 51" src="https://user-images.githubusercontent.com/60041910/215493758-1819fffc-6e1e-4133-b686-15c7b461624a.png">
