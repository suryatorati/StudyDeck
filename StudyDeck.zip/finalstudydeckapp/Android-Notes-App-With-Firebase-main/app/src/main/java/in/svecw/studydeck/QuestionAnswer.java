package in.svecw.studydeck;



public class QuestionAnswer {

    public static String question[] ={
            "Today it is Thursday.After 132 days,it will be",
            "A train 120 meters long is running with a speed of 60 km/hr. In what time will it pass a boy who is running at 6 km/hr in the direction opposite to that in which the train is going?",
            "Devesh can cover a certain distance in 1 hour 24 minutes by covering two-third of the distance at 6 km/hour and the rest at 7 km/hr. Calculate total distance.",
            "Find the H.C.F, if the numbers are in the ratio of 4 : 5 : 6 and their L.C.M. is 2400.",
            "What is the value of c , If 8 is 4% of a, and 4 is 8% of b. c equals b/a.",

            "Where was the first joint conference of army chiefs of India and African countries held?",
            "In which city will the RBI data centre and cyber security training institute be set up?",
            "In which country is Siniyah Island situated, which was in the news recently?",
            "Which song from RRR won Best Original Song at the Oscars 2023?",
            "Which bank is set to acquire Silicon Valley Bank and take control of all its deposits and loans?"
    };

    public static String choices[][] = {
            {"Monday", "Sunday", "Wednesday", "Thursday"},
            {"6.54 sec", "44.32 sec", "55 sec", "30.2 sec"},
            {"8 km", "9 km", "6 km", "7/5 km"},
            {"35", "20", "40", "67"},
            {"12", "1/4", "0.155", "None of these"},

            {"Pune", "Baroda", "Jaipur", "Bhopal"},
            {"Dehradun", "Bhuvaneswar", "Pune", "Rajkot"},
            {"USA", "UAE", "UK", "India"},
            {"Naatu Naatu", "Dosti", "Janani", "Komuram Bheemudo"},
            {"New Bank", "RBI", "HDFC Bank", "First Citizens Bank"}
    };

    public static String correctAnswers[] = {
            "Wednesday",
            "6.54 sec",
            "6 km",
            "20",
            "1/4",

            "Pune",
            "Bhuvaneswar",
            "UAE",
            "Naatu Naatu",
    		"First Citizens Bank"
};

}